from aiogram import Router, F
from aiogram.types import Message
from database import get_all_debtors

router = Router()

@router.message(F.text == "📋 Список должников")
async def list_debtors(message: Message):
    debtors = await get_all_debtors()

    if not debtors:
        await message.answer("✅ Должников нет! Все долги погашены.")
        return

    text = "📋 *Список должников:*\n\n"
    for i, d in enumerate(debtors, 1):
        text += (
            f"{i}. *{d['name']}*\n"
            f"   📱 {d['phone']}\n"
            f"   🛒 {d['product']}\n"
            f"   💰 {d['amount']} сом\n"
            f"   📅 Срок: {d['due_date']}\n"
            f"   🔔 ID: {d['id']}\n\n"
        )

    await message.answer(text, parse_mode="Markdown")
